<div class="header pb-7 pt-7 pt-md-8"
    style="background-image: url(../argon/img/theme/profile-cover.jpg); background-size: cover; background-position: center center;">
    <span class="mask bg-gradient-default opacity-3"></span>
    <div class="container-fluid">
        <div class="header-body">

        </div>
    </div>
</div>
