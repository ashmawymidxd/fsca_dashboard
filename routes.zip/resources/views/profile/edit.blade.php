@extends('layouts.app', ['title' => __('User Profile')])

@section('content')
    @include('users.partials.header', [
        'title' => __('Hello') . ' ' . auth()->user()->name,
        'description' => __(
            'This is your profile page. You can see the progress you\'ve made with your work and manage your projects or assigned tasks'),
        'class' => 'col-lg-12',
    ])

    <div class="container-fluid mt--5">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                <div class="card card-profile shadow-sm">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 order-lg-2">
                            <div class="card-profile-image">
                                <a href="#">
                                    <img style="height: 180px; object-fit:cover"
                                        src="{{ asset('assets/profile_images/' . auth()->user()->profile_image) }}"
                                        class="rounded-circle">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">

                    </div>
                    <div class="card-body mt-5">
                        <div class="text-center mt-5">
                            <h3>
                                {{ auth()->user()->name }}
                            </h3>
                        </div>
                        <div class="text-center">
                            <h5 class="h3">
                                {{ auth()->user()->email }}
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow-sm">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="mb-0">{{ __('Edit Profile') }}</h3>
                        </div>
                    </div>
                    <div class="card-body bg-white">
                        <form method="post" action="{{ route('profile.update') }}" autocomplete="off"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PATCH')

                            <h6 class="heading-small text-muted mb-4">{{ __('User information') }}</h6>

                            @if (session('status'))
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    {{ session('status') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif


                            <div class="pl-lg-4">
                                <div class="form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
                                    <label class="form-control-label" for="input-name">{{ __('Name') }}</label>
                                    <input type="text" name="name" id="input-name"
                                        class="form-control form-control-alternative{{ $errors->has('name') ? ' is-invalid' : '' }}"
                                        placeholder="{{ __('Name') }}" value="{{ old('name', auth()->user()->name) }}"
                                        required autofocus>

                                    @if ($errors->has('name'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
                                    <label class="form-control-label" for="input-email">{{ __('Email') }}</label>
                                    <input type="email" name="email" id="input-email"
                                        class="form-control form-control-alternative{{ $errors->has('email') ? ' is-invalid' : '' }}"
                                        placeholder="{{ __('Email') }}"
                                        value="{{ old('email', auth()->user()->email) }}" required>

                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="mt-3">
                                    <label class="form-control-label" for="">{{ __(' Profile Image') }}</label>
                                    <input type="file" id="profile_img" name="profile_image" hidden>
                                    <label for="profile_img"
                                        class="text-center border rounded bg-white shadow-sm w-100 p-2 ">
                                        -
                                    </label>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success mt-4 w-100">{{ __('Save') }}</button>
                                </div>
                            </div>
                        </form>
                        <hr class="my-4" />
                        <form method="post" action="{{ route('password.update') }}" autocomplete="off"
                            class="needs-validation" novalidate>
                            @csrf
                            @method('put')

                            <h6 class="heading-small text-muted mb-4">{{ __('Password') }}</h6>

                            @if (session('password_status'))
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    {{ session('password_status') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif

                            <div class="pl-lg-4">
                                <div
                                    class="form-group{{ $errors->updatePassword->has('current_password') ? ' has-danger' : '' }}">
                                    <label class="form-control-label"
                                        for="input-current-password">{{ __('Current Password') }}</label>
                                    <input type="password" name="current_password" id="input-current-password"
                                        class="form-control form-control-alternative{{ $errors->updatePassword->has('current_password') ? ' is-invalid' : '' }}"
                                        placeholder="{{ __('Current Password') }}" required autofocus>

                                    @if ($errors->updatePassword->has('current_password'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->updatePassword->first('current_password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group{{ $errors->updatePassword->has('password') ? ' has-danger' : '' }}">
                                    <label class="form-control-label" for="input-password">{{ __('New Password') }}</label>
                                    <input type="password" name="password" id="input-password"
                                        class="form-control form-control-alternative{{ $errors->updatePassword->has('password') ? ' is-invalid' : '' }}"
                                        placeholder="{{ __('New Password') }}" required>
                                    <small class="form-text text-muted">
                                        {{ __('Password must be at least 8 characters and contain a mix of letters, numbers, and symbols.') }}
                                    </small>

                                    @if ($errors->updatePassword->has('password'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->updatePassword->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div
                                    class="form-group{{ $errors->updatePassword->has('password_confirmation') ? ' has-danger' : '' }}">
                                    <label class="form-control-label"
                                        for="input-password-confirmation">{{ __('Confirm New Password') }}</label>
                                    <input type="password" name="password_confirmation" id="input-password-confirmation"
                                        class="form-control form-control-alternative{{ $errors->updatePassword->has('password_confirmation') ? ' is-invalid' : '' }}"
                                        placeholder="{{ __('Confirm New Password') }}" required>

                                    @if ($errors->updatePassword->has('password_confirmation'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->updatePassword->first('password_confirmation') }}</strong>
                                        </span>
                                    @endif
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-success mt-4 w-100">
                                        {{ __('Change password') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        @include('layouts.footers.auth')
    </div>
@endsection
